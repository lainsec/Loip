import requests
import sys
import os
import __sdk
from time import sleep

#api-endpoints
api = 'http://ip-api.com/'
method = 'json/'

#args
def args_lookup():
    try:
        arg = '-ip'
        return arg
    except IndexError:
        print("You commited an error. Try: loip.py -ip 'Query'")
        exit()


#clear screen with ascii
def clear_sc():
    try:
        os.system('clear')
        print(__sdk.banner)
    except:
        os.system('cls')
        print(__sdk.banner)

#clear screen 
def clear():
    try:
        os.system('clear')
    except:
        os.system('cls')
        
#ip lookup       
def ip_lookup(ip):
    clear_sc()
    print('Searching on database...')
    sleep(2)
    clear_sc()
    print('='*50,'+')
    data = requests.get(f'{api}{method}{ip}')
    response = data.json()
    for key,value in response.items():
        if value is not None:
            print(f'{key}:{value}')

args = args_lookup()

try:
    ip = sys.argv[2]
except IndexError:
    print("You commited an error. Try: loip.py -ip 'Query'")
    exit()
    
if sys.argv[1] == args:
    try:
        ip_lookup(ip)
    except Exception as e:
        print(e)
    except KeyboardInterrupt:
        clear()
        exit()
else:
    print(f'voce passou um parametro incorreto "{sys.argv[1]}"')
